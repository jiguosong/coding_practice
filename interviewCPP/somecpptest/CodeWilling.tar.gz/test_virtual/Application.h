/*
 * Application.h
 *
 *  Created on: Nov 7, 2016
 *      Author: songjiguo
 */

#ifndef SOMECPPTEST_APPLICATION_H_
#define SOMECPPTEST_APPLICATION_H_


// dummy

class Application {

};


#endif /* SOMECPPTEST_APPLICATION_H_ */
